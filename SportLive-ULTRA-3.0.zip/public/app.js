
const S={
 football:["כדורגל","⚽"],basketball:["כדורסל","🏀"],nba:["NBA","🏀"],baseball:["בייסבול","⚾"],hockey:["הוקי","🏒"],nfl:["NFL","🏈"],formula1:["Formula 1","🏎️"],handball:["כדוריד","🤾"],rugby:["רוגבי","🏉"],volleyball:["כדורעף","🏐"],afl:["AFL","🟠"]
};
const state={sport:"all",date:new Date(),view:"all",games:[],fav:new Set(JSON.parse(localStorage.getItem("sl_favs")||"[]"))};
const $=x=>document.querySelector(x), $$=x=>[...document.querySelectorAll(x)];
function esc(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));}
function dateISO(d){return new Date(d).toISOString().slice(0,10);}
function fmtDate(d){return new Intl.DateTimeFormat("he-IL",{weekday:"short",day:"2-digit",month:"long"}).format(d);}
function fmtTime(v){if(!v)return"—";const d=new Date(v);return isNaN(d)?"—":new Intl.DateTimeFormat("he-IL",{hour:"2-digit",minute:"2-digit"}).format(d);}
function status(m){
 const s=String(m.status||"").toUpperCase();
 const live=["1H","2H","Q1","Q2","Q3","Q4","P1","P2","P3","OT","ET","LIVE","HT","BT","IN PLAY"].some(x=>s.includes(x));
 const done=["FT","AOT","AP","AET","PEN","FINISHED"].includes(s)||/finished/i.test(m.statusLong||"");
 if(live)return {t:m.elapsed?`LIVE · ${m.elapsed}'`:"LIVE",c:"live",k:"live"};
 if(done)return {t:"הסתיים",c:"done",k:"finished"};
 return {t:fmtTime(m.date),c:"",k:"upcoming"};
}
function persist(){localStorage.setItem("sl_favs",JSON.stringify([...state.fav]));$("#favCount").textContent=state.fav.size;}
function setDateLabel(){$("#dateLabel").textContent=dateISO(state.date)===dateISO(new Date())?"היום":fmtDate(state.date);$("#dateFull").textContent=new Intl.DateTimeFormat("he-IL",{year:"numeric"}).format(state.date);}
function setSport(s){
 state.sport=s; state.view="all";
 $$(".side-link[data-sport]").forEach(x=>x.classList.toggle("active",x.dataset.sport===s));
 const name=s==="all"?"כל הספורט":S[s]?.[0]||s;
 $("#crumb").textContent=name;$("#pageTitle").textContent=s==="all"?"מה קורה בעולם הספורט?":name;
 $("#sectionTitle").textContent=s==="all"?"כל המשחקים":`משחקי ${name}`;
 load();
}
function rail(){
 $("#sportRail").innerHTML=`<button class="sport-btn ${state.sport==="all"?"active":""}" data-sport="all"><b>⌂</b> הכל</button>`+
 Object.entries(S).map(([k,v])=>`<button class="sport-btn ${state.sport===k?"active":""}" data-sport="${k}"><b>${v[1]}</b>${v[0]}</button>`).join("");
 $$(".sport-btn").forEach(b=>b.onclick=()=>setSport(b.dataset.sport));
}
function card(m,sport){
 const st=status(m), id=`${sport}:${m.id}`, on=state.fav.has(id);
 const score=(m.score?.home==null&&m.score?.away==null)?"—":`${m.score?.home??0} : ${m.score?.away??0}`;
 return `<article class="game" data-text="${esc((m.home?.name||"")+" "+(m.away?.name||"")+" "+(m.league?.name||""))}">
 <button class="fav ${on?"on":""}" data-fav="${esc(id)}">${on?"★":"☆"}</button>
 <div class="game-top"><div class="g-league">${m.league?.logo?`<img src="${esc(m.league.logo)}">`:""}<span>${esc(m.league?.name||S[sport]?.[0]||"ספורט")}</span></div><span class="g-status ${st.c}">${esc(st.t)}</span></div>
 <div class="teams"><div class="team">${m.home?.logo?`<img src="${esc(m.home.logo)}">`:""}${esc(m.home?.name||"—")}</div><div class="score">${score}<small>${sport==="formula1"?"EVENT":""}</small></div><div class="team">${m.away?.logo?`<img src="${esc(m.away.logo)}">`:""}${esc(m.away?.name||"—")}</div></div>
 <div class="game-foot">${m.venue?"⌖ "+esc(m.venue):"◷ "+esc(fmtTime(m.date))}</div>
 </article>`;
}
function render(){
 let arr=state.games.filter(g=>{const k=status(g).k;return state.view==="all"||k===state.view});
 const q=$("#search").value.trim().toLowerCase();
 if(q)arr=arr.filter(g=>(g.home?.name+" "+g.away?.name+" "+g.league?.name).toLowerCase().includes(q));
 $("#totalGames").textContent=state.games.length;$("#liveGames").textContent=state.games.filter(g=>status(g).k==="live").length;
 $("#games").innerHTML=arr.map(g=>card(g,g._sport||state.sport)).join("");
 $("#empty").classList.toggle("hidden",arr.length>0);
 $$(".fav").forEach(b=>b.onclick=()=>{const id=b.dataset.fav;if(state.fav.has(id))state.fav.delete(id);else state.fav.add(id);persist();render();});
}
async function health(){
 try{const r=await fetch("/api/health"),d=await r.json();const ok=!!d.configured;
  $("#connDot").classList.toggle("ok",ok);$("#connTitle").textContent=ok?"API מחובר":"API לא מחובר";$("#connText").textContent=ok?"מקור הנתונים פעיל. אפשר לבחור כל ענף נתמך.":"חבר API-Sports כדי לקבל נתונים אמיתיים מכל הענפים הנתמכים.";
  return ok;
 }catch{return false}
}
async function load(){
 $("#loading").classList.remove("hidden");$("#error").classList.add("hidden");$("#empty").classList.add("hidden");$("#games").innerHTML="";
 setDateLabel();rail();
 try{
  if(state.sport==="all"){
   const r=await fetch(`/api/all?date=${dateISO(state.date)}`),d=await r.json();if(!r.ok||!d.verified)throw Error(d.error||"API לא מחובר");
   state.games=d.data.flatMap(x=>x.data.map(g=>({...g,_sport:x.sport})));
  }else{
   const r=await fetch(`/api/games/${state.sport}?date=${dateISO(state.date)}`),d=await r.json();if(!r.ok||!d.verified)throw Error(d.error||"לא ניתן לאמת נתונים");
   state.games=(d.data||[]).map(g=>({...g,_sport:state.sport}));
  }
  $("#lastSync").textContent=new Intl.DateTimeFormat("he-IL",{hour:"2-digit",minute:"2-digit"}).format(new Date());
  $("#loading").classList.add("hidden");render();
 }catch(e){
  $("#loading").classList.add("hidden");$("#error").classList.remove("hidden");$("#errorText").textContent=e.message||"שגיאת חיבור";state.games=[];render();
 }
}
function modal(open){$("#apiModal").classList.toggle("hidden",!open);if(open){$("#apiKey").value=localStorage.getItem("sl_key")||"";$("#apiKey").focus();}}
async function save(){
 const key=$("#apiKey").value.trim(),msg=$("#apiMsg"),btn=$("#saveKey");if(!key){msg.textContent="צריך להדביק API Key.";return}
 btn.disabled=true;btn.textContent="בודק חיבור…";msg.textContent="";
 try{const r=await fetch("/api/config",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({key})}),d=await r.json();if(!r.ok)throw Error(d.error);
 localStorage.setItem("sl_key",key);msg.className="api-msg ok";msg.textContent="מחובר. טוען את מרכז הספורט…";setTimeout(()=>{modal(false);health();load()},250);
 }catch(e){msg.className="api-msg";msg.textContent=e.message||"שגיאה";}
 finally{btn.disabled=false;btn.innerHTML='חבר את SPORTLIVE <span>→</span>';}
}
$$(".side-link[data-sport]").forEach(b=>b.onclick=()=>setSport(b.dataset.sport));
$("#sportRail").onclick=e=>{const b=e.target.closest("[data-sport]");if(b)setSport(b.dataset.sport)};
$("#refresh").onclick=load;$("#prevDay").onclick=()=>{state.date.setDate(state.date.getDate()-1);load()};$("#nextDay").onclick=()=>{state.date.setDate(state.date.getDate()+1);load()};
$$(".view-tab").forEach(b=>b.onclick=()=>{$$(".view-tab").forEach(x=>x.classList.remove("active"));b.classList.add("active");state.view=b.dataset.view;render()});
$("#search").oninput=render;$("#apiSide").onclick=()=>modal(true);$("#connectCta").onclick=()=>modal(true);$("#apiMini").onclick=()=>modal(true);$("#errorApi").onclick=()=>modal(true);$("#close").onclick=()=>modal(false);$("#backdrop").onclick=()=>modal(false);$("#saveKey").onclick=save;
$("#showKey").onclick=()=>{const i=$("#apiKey");i.type=i.type==="password"?"text":"password";$("#showKey").textContent=i.type==="password"?"הצג":"הסתר"};
$("#liveBtn").onclick=()=>{$$(".view-tab").find(x=>x.dataset.view==="live")?.click()};$("#todayBtn").onclick=()=>{state.date=new Date();load()};
$("#favorites").onclick=()=>alert(state.fav.size?`יש לך ${state.fav.size} מועדפים.`:"עדיין לא סימנת מועדפים.");
$("#favCta").onclick=()=>$("#favorites").click();$("#logoBtn").onclick=()=>setSport("all");$("#mobileLogo").onclick=()=>setSport("all");
(async()=>{persist();const saved=localStorage.getItem("sl_key");if(saved){await fetch("/api/config",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({key:saved})}).catch(()=>{})}await health();await load();setInterval(()=>{if(state.view==="live")load()},30000)})();
