
import express from "express";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const PORT = process.env.PORT || 3000;
const ENV_KEY = process.env.API_SPORTS_KEY && process.env.API_SPORTS_KEY !== "PUT_YOUR_KEY_HERE" ? process.env.API_SPORTS_KEY : null;
const CACHE_TTL = Number(process.env.CACHE_TTL_MS || 45000);
let runtimeKey = ENV_KEY;
const cache = new Map();

app.use(express.json({ limit: "20kb" }));

const SPORTS = {
  football: { name:"כדורגל", icon:"⚽", base:"https://v3.football.api-sports.io", endpoint:"fixtures", dateParam:"date", kind:"teams" },
  basketball: { name:"כדורסל", icon:"🏀", base:"https://v1.basketball.api-sports.io", endpoint:"games", dateParam:"date", kind:"teams" },
  nba: { name:"NBA", icon:"🏀", base:"https://v2.nba.api-sports.io", endpoint:"games", dateParam:"date", kind:"teams" },
  baseball: { name:"בייסבול", icon:"⚾", base:"https://v1.baseball.api-sports.io", endpoint:"games", dateParam:"date", kind:"teams" },
  hockey: { name:"הוקי", icon:"🏒", base:"https://v1.hockey.api-sports.io", endpoint:"games", dateParam:"date", kind:"teams" },
  nfl: { name:"NFL", icon:"🏈", base:"https://v1.american-football.api-sports.io", endpoint:"games", dateParam:"date", kind:"teams" },
  handball: { name:"כדוריד", icon:"🤾", base:"https://v1.handball.api-sports.io", endpoint:"games", dateParam:"date", kind:"teams" },
  rugby: { name:"רוגבי", icon:"🏉", base:"https://v1.rugby.api-sports.io", endpoint:"games", dateParam:"date", kind:"teams" },
  volleyball: { name:"כדורעף", icon:"🏐", base:"https://v1.volleyball.api-sports.io", endpoint:"games", dateParam:"date", kind:"teams" },
  afl: { name:"AFL", icon:"🏉", base:"https://v1.afl.api-sports.io", endpoint:"games", dateParam:"date", kind:"teams" },
  formula1: { name:"Formula 1", icon:"🏎️", base:"https://v1.formula-1.api-sports.io", endpoint:"races", dateParam:null, kind:"races" },
};

function getKey(){ return runtimeKey; }
function cacheGet(k){ const x=cache.get(k); return x && Date.now()-x.t<CACHE_TTL ? x.v : null; }
function cacheSet(k,v){ cache.set(k,{t:Date.now(),v}); }

async function providerRequest(sportKey, params={}) {
  const sport = SPORTS[sportKey];
  if(!sport) throw Object.assign(new Error("Sport not supported"),{code:"SPORT"});
  if(!getKey()) throw Object.assign(new Error("API key is not connected"),{code:"NO_API_KEY"});
  const url = new URL(`${sport.base}/${sport.endpoint}`);
  Object.entries(params).forEach(([k,v])=>{ if(v!==undefined && v!==null && v!=="") url.searchParams.set(k,v); });
  const cacheKey=url.toString();
  const cached=cacheGet(cacheKey);
  if(cached) return {...cached,cached:true};
  const controller=new AbortController();
  const timer=setTimeout(()=>controller.abort(),10000);
  try{
    const r=await fetch(url,{signal:controller.signal,headers:{"x-apisports-key":getKey()}});
    const body=await r.json().catch(()=>({}));
    if(!r.ok) throw Object.assign(new Error(body?.message || `Provider HTTP ${r.status}`),{status:r.status,provider:body});
    if(body?.errors && Object.keys(body.errors).length) throw Object.assign(new Error(JSON.stringify(body.errors)),{status:400,provider:body});
    const out={...body,fetchedAt:new Date().toISOString()};
    cacheSet(cacheKey,out);
    return out;
  } finally { clearTimeout(timer); }
}

function normalizeFootball(x){
  return {id:x.fixture?.id,date:x.fixture?.date,status:x.fixture?.status?.short,statusLong:x.fixture?.status?.long,elapsed:x.fixture?.status?.elapsed,
    league:{name:x.league?.name,logo:x.league?.logo,country:x.league?.country},
    home:{name:x.teams?.home?.name,logo:x.teams?.home?.logo},away:{name:x.teams?.away?.name,logo:x.teams?.away?.logo},
    score:{home:x.goals?.home,away:x.goals?.away},venue:x.fixture?.venue?.name};
}
function normalizeTeams(x){
  const teams=x.teams||x.teams?.home||{};
  const home=x.teams?.home || {};
  const away=x.teams?.away || {};
  const scores=x.scores || x.score || {};
  return {id:x.id||x.game?.id,date:x.date||x.game?.date,status:x.status?.short||x.status?.type||x.game?.status?.short,statusLong:x.status?.long||x.status?.description||x.game?.status?.long,
    league:{name:x.league?.name||x.league?.name,logo:x.league?.logo,country:x.country?.name||x.country},
    home:{name:home.name||teams.home?.name,logo:home.logo||teams.home?.logo},away:{name:away.name||teams.away?.name,logo:away.logo||teams.away?.logo},
    score:{home:scores.home?.total ?? scores.home?.points ?? scores.home ?? null,away:scores.away?.total ?? scores.away?.points ?? scores.away ?? null},
    venue:x.venue?.name||x.game?.venue?.name};
}
function normalizeRace(x){
  return {id:x.id,date:x.date||x.date_start||x.time,status:x.status||"Race",statusLong:x.type||x.name||"Grand Prix",
    league:{name:x.competition?.name||"Formula 1",logo:null,country:x.country?.name||""},
    home:{name:x.circuit?.name||x.name||"Grand Prix",logo:null},away:{name:x.circuit?.city||x.city||"",logo:null},
    score:{home:null,away:null},venue:x.circuit?.name||x.location?.name||""};
}

app.get("/api/sports",(req,res)=>res.json(Object.entries(SPORTS).map(([id,s])=>({id,...s,base:undefined,endpoint:undefined}))));

app.get("/api/health",(_req,res)=>res.json({configured:Boolean(getKey()),provider:"API-Sports",serverTime:new Date().toISOString()}));

app.post("/api/config",(req,res)=>{
  const key=String(req.body?.key||"").trim();
  if(!key || key.length<20 || key.length>300) return res.status(400).json({ok:false,error:"ה־API Key נראה לא תקין."});
  runtimeKey=key; cache.clear();
  res.json({ok:true,configured:true});
});
app.delete("/api/config",(_req,res)=>{runtimeKey=ENV_KEY;cache.clear();res.json({ok:true,configured:Boolean(runtimeKey)})});

app.get("/api/games/:sport",async(req,res)=>{
  const sportKey=req.params.sport;
  try{
    const sport=SPORTS[sportKey];
    if(!sport) return res.status(404).json({verified:false,error:"Sport not found"});
    const date=req.query.date || new Date().toISOString().slice(0,10);
    let data;
    if(sport.kind==="races"){
      const season=Number(req.query.season||new Date().getFullYear());
      data=await providerRequest(sportKey,{season});
    } else {
      data=await providerRequest(sportKey,{[sport.dateParam]:date,timezone:"Asia/Jerusalem"});
    }
    const rows=(data.response||[]).map(x=>sportKey==="football"?normalizeFootball(x):sport.kind==="races"?normalizeRace(x):normalizeTeams(x));
    res.json({verified:true,sport:sportKey,fetchedAt:data.fetchedAt,count:rows.length,data:rows});
  }catch(e){
    res.status(e.code==="NO_API_KEY"?503:(e.status||502)).json({verified:false,code:e.code||"PROVIDER_ERROR",error:e.message,data:[]});
  }
});

app.get("/api/all",async(req,res)=>{
  const date=req.query.date || new Date().toISOString().slice(0,10);
  const keys=Object.keys(SPORTS).filter(k=>k!=="formula1");
  const results=await Promise.allSettled(keys.map(k=>providerRequest(k,{date,timezone:"Asia/Jerusalem"})));
  const data=[];
  results.forEach((r,i)=>{
    if(r.status==="fulfilled"){
      const k=keys[i], rows=(r.value.response||[]).slice(0,12).map(x=>k==="football"?normalizeFootball(x):normalizeTeams(x));
      data.push({sport:k,count:rows.length,fetchedAt:r.value.fetchedAt,data:rows});
    }
  });
  res.json({verified:Boolean(getKey()),date,data});
});

app.use(express.static(path.join(__dirname,"public")));
app.get("*splat",(_req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`SPORTLIVE ULTRA → http://localhost:${PORT}`));
