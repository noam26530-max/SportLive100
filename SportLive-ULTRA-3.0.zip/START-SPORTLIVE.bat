@echo off
title SPORTLIVE ULTRA
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
 echo Node.js is not installed. Install Node.js LTS and run again.
 pause
 exit /b 1
)
if not exist node_modules (
 echo Installing SPORTLIVE...
 call npm install
 if errorlevel 1 (echo Install failed.&pause&exit /b 1)
)
start "" http://localhost:3000
npm start
pause
